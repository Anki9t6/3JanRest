package tests;

public class pozoClass {
	private String name;
	private String job;
	
	 public String getName() {
	        return name;
	    }

	    // Setter method for name
	    public void setName(String name) {
	        this.name = name;
	    }
	
	    public String getJob() {
	        return job;
	    }

	    // Setter method for name
	    public void setJob(String job) {
	        this.job = job;
	    }
}
